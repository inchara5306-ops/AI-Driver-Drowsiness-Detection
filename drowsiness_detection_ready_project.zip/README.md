# AI Drowsiness Detection

Detects driver drowsiness in real time from a webcam by tracking **closed
eyes**, **yawning**, and **head position**, using MediaPipe Face Mesh +
OpenCV. No cloud calls, no GPU required — runs on a laptop CPU at 20-30 FPS.

## How it works

```
Camera Frame
    -> MediaPipe Face Mesh (468 landmarks)
    -> Eye Aspect Ratio (EAR)        -> closed-eye detection
    -> Mouth Aspect Ratio (MAR)      -> yawn detection
    -> Head Pose (solvePnP)          -> head-nod / look-away detection
    -> DrowsinessStateMachine        -> AWAKE / DROWSY decision
    -> On-screen overlay + beep alert
```

Full explanation, architecture diagram, and evaluation are in `report.docx`.

## Files

| File | Purpose |
|---|---|
| `utils.py` | EAR / MAR / head-pose math + the `DrowsinessStateMachine` decision logic |
| `main.py` | Real-time webcam app — run this on your own machine with a camera |
| `simulate_demo.py` | Camera-free demo: feeds a synthetic 60s driving signal through the **real** state machine and plots the result (useful for grading/demo without a webcam) |
| `requirements.txt` | Dependencies |
| `assets/simulation_result.png` | Output of the last `simulate_demo.py` run |

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Run the live webcam demo

```bash
python main.py
```
- Look at the camera normally for the first ~1 second (calibration).
- Close your eyes for ~1 second, or yawn, or drop your head — a red border
  and beep should appear within a second.
- Press `q` to quit.

## Run the offline / no-camera demo

```bash
python simulate_demo.py
```
Prints every AWAKE→DROWSY transition with the triggering reason, and saves
`assets/simulation_result.png` showing EAR/MAR/head-pitch traces alongside
the final alert output.

## Tuning

All thresholds live in `DrowsinessStateMachine.__init__` in `utils.py`:

| Parameter | Default | Meaning |
|---|---|---|
| `ear_threshold` | 0.21 | EAR below this = eyes considered closed |
| `ear_consec_frames` | 15 | Consecutive closed-eye frames before alerting (~0.5s @30fps) |
| `mar_threshold` | 0.60 | MAR above this = mouth considered open (yawn) |
| `yawn_count_trigger` | 2 | Yawns within `yawn_window_seconds` before alerting |
| `pitch_drop_threshold` | 15° | Head pitch drop from calibrated baseline before alerting |
| `head_consec_frames` | 20 | Consecutive frames head must stay down before alerting |

## Limitations / future work

- Single-face only (`max_num_faces=1`); assumes driver is in frame.
- Needs decent cabin lighting — add an IR camera for night driving.
- Head-pose model uses generic 3D face proportions, not per-driver calibrated.
- Next steps: log events to detect micro-sleep frequency over a trip, integrate
  with vehicle telemetry (speed) to suppress false alerts when parked.


## Arduino hardware integration (added)

1. Upload `drowsiness_arduino.ino` to an Arduino Uno using Arduino IDE.
2. Wire LEDs, buzzer and relay according to the wiring diagram supplied with the hardware pack.
3. Install dependencies with `python -m pip install -r requirements.txt`.
4. Close Arduino IDE Serial Monitor, then run `python main.py`.
5. Enter the Arduino port shown in Device Manager (for example `COM3`). Press Enter to run without hardware.
6. The app sends `S` while awake and `D` when drowsy or no face is detected. The Arduino sketch's 3-second timeout is a fail-safe.

**Important:** This integration currently uses `S` and `D`; it does not yet generate a separate `W` early-warning state. It is a classroom demonstration, not a vehicle safety device. Use only a small low-voltage demo motor.
