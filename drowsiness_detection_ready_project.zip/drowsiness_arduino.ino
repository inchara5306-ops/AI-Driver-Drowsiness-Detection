/*
  Drowsiness Detection - Arduino Uno controller
  ----------------------------------------------
  The PC (Python + webcam) sends ONE character over USB serial (9600 baud):
    'S' = Safe / alert      -> Green LED ON,  motor RUNS
    'W' = Warning (fatigue) -> Red LED blinks, short beeps, motor RUNS
    'D' = Drowsy            -> Red LED ON, continuous buzzer, relay OFF -> motor STOPS

  Fail-safe: if no character arrives for 3 s (camera/PC crashed), the
  Arduino treats it as drowsy and cuts the motor.

  Wiring (see report for diagram):
    D8  -> 220R -> Green LED -> GND
    D9  -> 220R -> Red LED   -> GND
    D10 -> Buzzer (+)        ; Buzzer (-) -> GND
    D7  -> Relay IN          ; Relay VCC -> 5V, GND -> GND
    Motor circuit: Battery(+) -> Relay COM, Relay NO -> Motor(+), Motor(-) -> Battery(-)
    (Battery GND does NOT need to touch the Arduino; relay isolates it.)
*/

const int GREEN_LED = 8;
const int RED_LED   = 9;
const int BUZZER    = 10;
const int RELAY     = 7;

// Most blue 5V relay modules are ACTIVE-LOW (LOW = relay ON).
// If yours is active-HIGH, set this to false.
const bool RELAY_ACTIVE_LOW = true;

const unsigned long TIMEOUT_MS = 3000;

char state = 'D';                 // start with motor OFF until PC says it's safe
unsigned long lastMsg = 0;
unsigned long lastToggle = 0;
bool blinkOn = false;

void motorRun(bool run) {
  bool pinLevel = RELAY_ACTIVE_LOW ? !run : run;
  digitalWrite(RELAY, pinLevel ? HIGH : LOW);
}

void setup() {
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(RELAY, OUTPUT);
  motorRun(false);                // motor off at boot
  Serial.begin(9600);
  lastMsg = millis();
}

void loop() {
  // 1) Read latest command from PC
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == 'S' || c == 'W' || c == 'D') {
      state = c;
      lastMsg = millis();
    }
  }

  // 2) Fail-safe if PC stops talking
  if (millis() - lastMsg > TIMEOUT_MS) state = 'D';

  // 3) Drive outputs
  unsigned long now = millis();

  if (state == 'S') {
    digitalWrite(GREEN_LED, HIGH);
    digitalWrite(RED_LED, LOW);
    digitalWrite(BUZZER, LOW);
    motorRun(true);
  }
  else if (state == 'W') {
    digitalWrite(GREEN_LED, LOW);
    motorRun(true);
    if (now - lastToggle > 400) {          // blink + beep every 400 ms
      lastToggle = now;
      blinkOn = !blinkOn;
      digitalWrite(RED_LED, blinkOn);
      digitalWrite(BUZZER, blinkOn);
    }
  }
  else { // 'D'
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(RED_LED, HIGH);
    digitalWrite(BUZZER, HIGH);
    motorRun(false);                       // cut motor power
  }
}
